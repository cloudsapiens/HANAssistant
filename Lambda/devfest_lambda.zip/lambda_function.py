
import pyhdb
import os
import json
import logging
import boto3
import base64
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

def AwsCto(intent_request):
    get_secrets = get_secret()
    db_user = json.dumps(get_secrets['DB_USER']).replace('"', '')
    db_password = json.dumps(get_secrets['DB_PASSWORD']).replace('"', '')
    connect = pyhdb.connect(os.environ["DB_HOST"], os.environ["DB_PORT"], db_user, db_password) 
    cursor = connect.cursor()
    cursor.execute("SELECT NAME FROM aws_leaders WHERE POSITION='CTO'")
    sql_result_awscto = json.dumps(cursor.fetchall()).replace("[", "").replace("]", "").replace('"', '')
    response =  { "dialogAction": { "fulfillmentState": "Fulfilled", "type":"Close", "message": { "contentType":"PlainText", "content": str(sql_result_awscto)}}}
    return response
    connect.close()

def AwsCeo(intent_request):
    get_secrets = get_secret()
    db_user = json.dumps(get_secrets['DB_USER']).replace('"', '')
    db_password = json.dumps(get_secrets['DB_PASSWORD']).replace('"', '')
    connect = pyhdb.connect(os.environ["DB_HOST"], os.environ["DB_PORT"], db_user, db_password) 
    cursor = connect.cursor()
    cursor.execute("SELECT NAME FROM aws_leaders WHERE POSITION='CEO'")
    sql_result_awsceo = json.dumps(cursor.fetchall()).replace("[", "").replace("]", "").replace('"', '')
    response =  { "dialogAction": { "fulfillmentState": "Fulfilled", "type":"Close", "message": { "contentType":"PlainText", "content": str(sql_result_awsceo)}}}
    return response
    connect.close()

def dispatch(intent_request):
    logger.debug('dispatch userId={}, intentName={}'.format(intent_request['userId'], intent_request['currentIntent']['name']))
    intent_name = intent_request['currentIntent']['name']
    if intent_name == 'DbQueryCeo':
        return AwsCeo(intent_request)
    elif intent_name == 'DbQueryCto':
        return AwsCto(intent_request)
    raise Exception('Intent with name ' + intent_name + ' not supported')

def get_secret():
    secret_name = "devfest-hana-credentials"
    region_name = "us-east-1"
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )
    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        if e.response['Error']['Code'] == 'DecryptionFailureException':
            raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            raise e
    else:
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
        else:
            decoded_binary_secret = base64.b64decode(get_secret_value_response['SecretBinary'])
    secrets = json.loads(secret)
    return secrets

def lambda_handler(event, context):
    return dispatch(event)



